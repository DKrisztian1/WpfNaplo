﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using Microsoft.Win32;

namespace WpfOsztalyzas
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string fajlNev = "naplo.txt";
        //Így minden metódus fogja tudni használni.
        ObservableCollection<Osztalyzat> jegyek = new ObservableCollection<Osztalyzat>();

        

        public MainWindow()
        {
            InitializeComponent();
            // todo Fájlok kitallózásával tegye lehetővé a naplófájl kiválasztását!
            // Ha nem választ ki semmit, akkor "naplo.csv" legyen az állomány neve. A későbbiekben ebbe fog rögzíteni a program.

            datDatum.DisplayDateEnd = DateTime.Today;

            var dialog = new OpenFileDialog();
            if (dialog.ShowDialog() == true)
            {
                fajlNev = dialog.FileName;
                Betoltes();
            }
            else
            {
                fajlNev = "naplo.txt";
                Betoltes();
            }
        }
        
        private void Betoltes()
        {
            jegyek.Clear();
            StreamReader sr = new StreamReader(fajlNev);
            while (!sr.EndOfStream)
            {
                string[] mezok = sr.ReadLine().Split(";");
                Osztalyzat ujJegy = new Osztalyzat(mezok[0], mezok[1], mezok[2], int.Parse(mezok[3]));
                if (rdKerBolVez.IsChecked == true)
                {
                    mezok[0] = ujJegy.ForditottNev(mezok[0]);
                    ujJegy = new Osztalyzat(mezok[0], mezok[1], mezok[2], int.Parse(mezok[3]));
                    jegyek.Add(ujJegy);
                }
                else
                {
                    jegyek.Add(ujJegy);
                }
            }
            sr.Close();
            dgJegyek.ItemsSource = jegyek;
            Kiszamitas();
        }

        private void Kiszamitas()
        {
            double osszeg = 0;
            foreach (var item in jegyek)
            {
                osszeg = osszeg + item.Jegy; 
            }
            lblJegyekSzama.Content = jegyek.Count;
            lblAtlag.Content = Math.Round(osszeg / jegyek.Count, 2);
            lblFajlNev.Content = fajlNev.Split(@"\")[fajlNev.Split(@"\").Count()-1];
        }

        private void btnRogzit_Click(object sender, RoutedEventArgs e)
        {
            if (txtNev.Text.Contains(' ') && txtNev.Text.Split(" ")[0].Length>2 && txtNev.Text.Split(" ")[1].Length > 2)
            {
                string csvSor = $"{txtNev.Text};{datDatum.Text};{cboTantargy.Text};{sliJegy.Value}";
                StreamWriter sw = new StreamWriter(fajlNev, append: true);
                sw.WriteLine(csvSor);
                sw.Close();
                Betoltes();
            }
            else
            {
                MessageBox.Show("Rosszul adtad meg a nevet!");
            }
        }

        private void btnBetolt_Click(object sender, RoutedEventArgs e)
        {
            Betoltes();
        }

        private void sliJegy_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            lblJegy.Content = sliJegy.Value;
        }

        private void btnModosit_Click(object sender, RoutedEventArgs e)
        {
            if (dgJegyek.SelectedIndex<0)
            {
                MessageBox.Show("Nem választott ki elemet!", "HIBA!", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            Osztalyzat kivalasztottElem = (Osztalyzat)dgJegyek.SelectedItem;
            txtNev.Text = kivalasztottElem.Nev;
            datDatum.Text = kivalasztottElem.Datum;
            cboTantargy.SelectedItem = kivalasztottElem.Tantargy;
            sliJegy.Value = kivalasztottElem.Jegy;

            jegyek.Remove(kivalasztottElem);
            
        }

        private void btnTorles_Click(object sender, RoutedEventArgs e) //a txt-bol meg nem torli ki
        {
            if (dgJegyek.SelectedIndex < 0)
            {
                MessageBox.Show("Nem választott ki elemet!", "HIBA!", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            else
            {
                Osztalyzat kivalasztottElem = (Osztalyzat)dgJegyek.SelectedItem;
                jegyek.Remove(kivalasztottElem);
            }
        }
    }
}

